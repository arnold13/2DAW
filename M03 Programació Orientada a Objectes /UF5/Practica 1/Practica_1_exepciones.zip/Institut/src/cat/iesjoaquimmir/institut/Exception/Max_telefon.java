/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.institut.Exception;

/**
 *
 * @author Arnold
 */
public class Max_telefon extends RuntimeException {

    /**
     * Creates a new instance of <code>Max_telefon</code> without detail
     * message.
     */
    public Max_telefon() {
    }

    /**
     * Constructs an instance of <code>Max_telefon</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public Max_telefon(String msg) {
        super(msg);
    }
    
    
    
    
    
}
