/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.geoapp.model.businesslayer.entities;

/**
 *
 * @author soraccari
 */
public class Cercle {
    
    //<editor-fold defaultstate="collapsed" desc="Variables">
    
    /**
     * @param radio El radio del poligono
     * @param pi Devuelve el valor del pi siendo una constante de valo 3.14;
     */
    
    int radio;
    final double pi = 3.14;
    
//</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Constructor">

    /**
    * @param radio Define el radio del poligono en el constructor
    */
    
    public Cercle(int radio) {
        this.setRadio(radio);
    }
    
    /**
    *
    * Define el radio del poligono por defecto en el constructor
    * 
    */
    
    public Cercle(){
        this.setRadio(0);
    }
   
    
     

//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Getters y setters">
    
    /**
    * @return devuelve el radio
    *
    */
    
      public int getRadio(){
        
        return radio;
        
       /**
        * 
        * Permite modificar el valor del radio del actual objeto vinculado a esta classe;
        * 
        */ 
        
    }
    
    public int setRadio(int radio) {
        this.radio = radio;
        return radio;
    }

//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Metodos">
   
    /**
    *
    * @return Calcula el perimetro del poligono
    * 
    */
    
    public double Calcular_perimetro() {
       
        double perimetro = 2 * pi * getRadio(); // El pi es double, por lo que la variable debe ser double, ya que si no lo es perderiamos datos.
        
        return perimetro;
    }
     
        /**
    *
    * @return Calcula el area del poligono
    * 
    */
    
    
     public Double Calcular_area() {
        Double area =  pi * (getRadio() * getRadio()) ;
        
        return area;
    }
    
  
    
//</editor-fold>
    
    
    
}
