/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.geoapp.model.businesslayer.usuari;

import cat.iesjoaquimmir.geoapp.model.businesslayer.entities.Cercle;
import cat.iesjoaquimmir.geoapp.model.businesslayer.entities.Rectangle;
import cat.iesjoaquimmir.geoapp.model.businesslayer.entities.Sphere;
import cat.iesjoaquimmir.geoapp.model.businesslayer.entities.Square;
import java.util.Scanner;

/**
 * Clase Alumno
 *
 * Contiene informacion de cada Alumno
 *
 * @author Arnold
 * @version 7
 */
public class Alumno {
    
    //<editor-fold defaultstate="collapsed" desc="Variable">
    
      /**
     * 
     * 
     * @param nom La variable nombre de la classe del alumno. 
     */
    
    private String nom;
//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Constructor">
    
    /**
     * Define la informacion del alumno (Solo el nombre);
     * 
     *   
     */
    
     public Alumno(String nom) {
        this.setNom(nom);
    }

     
     /**
     * Deja por defecto la posicion del nombre al llamar a la classe alumno
     * 
     *   
     */
     
    public Alumno() {
        this.setNom("Sin_Nombre");
    }
     
     
     
//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Getters y setters">
    
    /**
     * 
     * 
     * @return Devuelve el nombre
     */
    
       public String getNom() {
        return nom;
    }
       
         /**
     * 
     * 
     * @return Define el nombre
     */

    public String setNom(String nom) {
        this.nom = nom;
        return nom;
    }

     
//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Metodos">
    
    
    /**
     * 
     * Da a escoger un poligono por consola y muestra su informacion
     * 
     * 
     */
    
    public void Poligos_a_calcular(){
        
        //<editor-fold defaultstate="collapsed" desc="Variables">
        
        /**
        *
        *
        * @param sc  variable de una instancia de la classe scanner,util para leer los datos introducidos por consola, como el siguiente en strings:
        * 
        * @see java.util.Scanner#nextLine();
        * 
        * 
        * 
        * 
        *
        */
        
        
        
         Scanner sc = new Scanner(System.in);
         
         
         /**
          * 
          * @param Linea  Variable que recibira el texto de la variable que instació la classe scanner
          * 
          */
         
         String linea;

        
//</editor-fold>

        
        
        System.out.println("Que poligono desearias escoger?\n\n"
                + "(1: Rectangle , 2: Square , 3: Cercle , 4: Sphere )");
        
        
        linea = sc.nextLine();
        
        switch(linea){
            
            case("1"):
                
                System.out.println("Inserta las medidas costado base");
                
                int costado_base = sc.nextInt();
                
                System.out.println("Inserta las medidas costado lateral");
                
                int costado_lateral = sc.nextInt();

                Rectangle rectangulo = new Rectangle(costado_base, costado_lateral);
                
                System.out.println("Area del rectangulo : " + rectangulo.Calcular_area() + "\n"
                        + "Perimetro del rectangulo: " + rectangulo.Calcular_perimetro());
            
            break;
            
             case("2"):
                 
                 System.out.println("Inserta las medidas del costado ");
                
                int costado = sc.nextInt();
                

                Square cuadrado = new Square(costado);
                
                System.out.println("Area del cuadrado : " + cuadrado.Calcular_area() + "\n"
                        + "Perimetro del cuadrado: " + cuadrado.Calcular_perimetro());
            
            break;
            
             case("3"):
                 
                    System.out.println("Inserta las medidas del radio ");
                
                int radio = sc.nextInt();
                

                 Cercle circulo = new Cercle(radio);
                
                System.out.println("Area del circulo : " + circulo.Calcular_area() + "\n"
                        + "Perimetro del circulo: " + circulo.Calcular_perimetro());
            
            break;
            
             case("4"):
                 
                   System.out.println("Inserta las medidas del radio ");
                
                radio = sc.nextInt();
                
                 Sphere esfera = new Sphere(radio);
                
                System.out.println("Area del esfera : " + esfera.Calcular_area() + "\n"
                        + "Perimetro del esfera: " + esfera.Calcular_perimetro());
            
            break;
                    
        }
        
    }
    
    //<editor-fold defaultstate="collapsed" desc="Metodo sobrecargado">
    
    /**
     * 
     * @return Devuelve un string al llamar a la classe e imprimirla
     */
    
     @Override
    public String toString() {
        return String.format("Bienvenido alumno con el nombre de: %s \n", getNom());
    }

    
    
//</editor-fold>
    
//</editor-fold>

   
  
   
    
}
