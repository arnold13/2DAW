/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.geoapp.model.businesslayer.entities;

/**
 *
 * @author soraccari
 */
public class Sphere {
   
    //<editor-fold defaultstate="collapsed" desc="Variables">
    /**
     * @param radio Variable que marca el radio de la esfera
     */
    int radio;
    
    /**
     *  @param pi = Variable cuyo valor guarda la constante PI.
     */
    
    final double pi = 3.14;
    
//</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Constructor">

    /**
     * 
     * @param radio Especifica el radio 
     * 
     * Constructor de esfera con opcion de definir el radio de la esfera;
     */
    
    public Sphere(int radio) {
        this.setRadio(radio);
    }
   
    /**
     * 
     * Constructor de esfera definiendo los atributos por defecto
     * 
     */
    
     public Sphere() {
        this.setRadio(0);
    }
   
    
     

//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Getters y setters">
    
     /**
      * 
      * @return Devuelve el radio;
      */
     
      public int getRadio(){
        
        return radio;
        
    }
      
      /**
       * 
       * @param radio Define el nuevo radio
       * @return Establece un nuevo valor sobre el atributo radio del objeto de tipo Alumno;
       */
    
    public int setRadio(int radio) {
        this.radio = radio;
        return radio;
    }

//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Metodos">
    
    /**
     * 
     * @return Calcula el perimetro
     */
   
    public double Calcular_perimetro() {
       
        double perimetro = 2 * pi * getRadio(); // El pi es double, por lo que la variable debe ser double, ya que si no lo es perderiamos datos.
        
        return perimetro;
    }
    
    /**
     * 
     * @return Calcula el area
     */
     
     public Double Calcular_area() {
       
         double area = 4 * pi *  (getRadio()*getRadio());
        
        return area;
    }
    
  
    
//</editor-fold> 
    
}
