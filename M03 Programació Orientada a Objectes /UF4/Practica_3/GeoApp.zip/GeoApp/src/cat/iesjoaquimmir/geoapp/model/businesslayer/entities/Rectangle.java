/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.geoapp.model.businesslayer.entities;

/**
 *
 * @author soraccari
 */
public class Rectangle {

    //<editor-fold defaultstate="collapsed" desc="Variables">
    
    /**
     * @param costado_Base Define el costado base del poligono (Rectangulo)
     */
    
    int costado_base;
    
    /**
    * @param costado_lateral Define el costado lateral del poligono (Rectangulo)
    */
    
    int costado_lateral;
//</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Constructor">

    /**
     * 
     * @param costado_base Define el costado base del objeto de tipo de esta classe;
     * @param costado_lateral Define el costado lateral del objeto de tipo de esta classe;
     */
    
    public Rectangle(int costado_base, int costado_lateral) {
        this.setCostado_base(costado_base);
        this.setCostado_lateral(costado_lateral);
    }
    
    /**
     * Marca los atributos del rectangulo por defecto (0);
     */

        public Rectangle() {
        this.setCostado_base(0);
        this.setCostado_lateral(0);

    }
    

//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Getters y setters">
   
        /**
         * 
         * @return devuelve el costado base
         */
        
    public int getCostado_base(){
        
       return costado_base;
    }

    /**
     * 
     * @param costado_base define el costado base del objeto creado mediante esta classe;
     * @return devuelve el costado base
     */
    
    public int setCostado_base(int costado_base) {
        this.costado_base = costado_base;
        return costado_base;
    }
    
    /**
     * 
     * @return devuelve el costado lateral
     */

    public int getCostado_lateral() {
        return costado_lateral;
    }
     
    /**
     * 
     * @param costado_lateral define el costado lateral del objeto creado mediante esta classe;
     * @return devuelve el costado lateral
     */
    
     public int setCostado_lateral(int costado_lateral) {
        this.costado_lateral = costado_lateral;
        return costado_lateral;
    }

//</editor-fold>
     
    //<editor-fold defaultstate="collapsed" desc="Metodos">
     
     /**
      * 
      * @return Devuelve el perimetro del poligono
      */
   
       public int Calcular_perimetro(){
        
        int perimetro = 2 * getCostado_base() + 2 * getCostado_lateral();

        return perimetro;
        
    }
       
       /**
        * 
        * @return Devuelve el area del poligono
        */
     
     public int Calcular_area() {
        int area = getCostado_base() * getCostado_lateral();
        
        return area;
    }
    
  
    
//</editor-fold>
    
    
    
}
