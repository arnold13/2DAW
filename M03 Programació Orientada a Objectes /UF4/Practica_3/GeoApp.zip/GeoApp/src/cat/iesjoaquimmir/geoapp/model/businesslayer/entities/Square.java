/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.geoapp.model.businesslayer.entities;

/**
 *
 * @author soraccari
 */
public class Square {
    
     //<editor-fold defaultstate="collapsed" desc="Variables">
    
    /**
     * @param Variable global perteneciente costado del cuadrado de la classe cuadrado;
     */
    
    private int costado;
//</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Constructor">
    
    /**
     * Constructor del cuadrado
     * 
     * @param costado Define el costado al crear el nuevo objeto del tipo alumno
     */
    
     public Square(int costado) {
        this.setCostado(costado);
    }

     
     /**
      * 
      * Constructor del cuadrado que define los atributos del cuadrado por defecto;
      * 
      * 
      */
     
    public Square() {
        this.setCostado(0);

    }

     
  
    
//</editor-fold>
     
     //<editor-fold defaultstate="collapsed" desc="Getters y setters">
     
    /**
     * 
     * @return  Muestra el valor del costado del cuadrado
     */
    
       public int getCostado() {
        return costado;
    }

       /**
        * 
        * @param costado Valor del costado del cuadrado
        * @return Define un nuevo valor del costado del objeto creado del tipo Alumno
        */
       
    public int setCostado(int costado) {
        this.costado = costado;
        return costado;
    }
     
//</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Metodos">
    
    /**
     * 
     * @return Devuelve el perimetro del cuadrado
     */
    
        public int Calcular_perimetro(){
        
        int perimetro = getCostado() * 4;

        return perimetro;
        
    }
        
    /**
     * 
     * @return Devuelve el area del cuadrado
     */
        
    public int Calcular_area(){
        
       int area = getCostado() * getCostado(); 
       
       return area;
    }
    

    
//</editor-fold>
    
}
