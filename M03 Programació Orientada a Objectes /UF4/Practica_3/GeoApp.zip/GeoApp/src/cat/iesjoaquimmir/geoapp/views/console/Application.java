/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.iesjoaquimmir.geoapp.views.console;

import cat.iesjoaquimmir.geoapp.model.businesslayer.entities.Square;
import cat.iesjoaquimmir.geoapp.model.businesslayer.usuari.Alumno;

/**
 *
 * @author soraccari
 */
public class Application {
   
    
    public static void main(String[] args) {
        
        // Ejercicio y Advanced 1 =
        
        Alumno alumne = new Alumno();
        alumne.setNom("Arnold");
        
        System.out.println(alumne);
        
        alumne.Poligos_a_calcular();
        
        // Advanced 2 =
        
        System.out.println("\n\n\nADVANCED 2:");
        
        System.out.println("\nCuadrado con atributos simplificados \n ------------------");
        
            Square cuadrado = new Square();
            cuadrado.setCostado(3);
            
            System.out.println("Area del cuadrado : "+cuadrado.Calcular_area() + "\n"
                    + "Perimetro del cuadrado: " +cuadrado.Calcular_perimetro() + "\n" );
            
            
       System.out.println("Cuadrado con atributos minimos \n ------------------");     

            cuadrado = new Square();

            
            System.out.println("Area del cuadrado : "+cuadrado.Calcular_area() + "\n"
                    + "Perimetro del cuadrado: " +cuadrado.Calcular_perimetro() + "\n" );
        
    }
    
}
